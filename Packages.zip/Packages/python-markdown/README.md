# sublime-markdown

Sublime dependency for Python Markdown

Current version: 3.1.1

# License

https://github.com/facelessuser/sublime-markdown/blob/master/st3/LICENSE.md
